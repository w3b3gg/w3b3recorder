;((ct) => {
  const _game = window.document.querySelector('canvas')
  ct.w3b3.recorder.initialize(_game)
})(ct)