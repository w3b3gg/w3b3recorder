# W3B3 Recorder to ct.js - Catmods
> Record gameplays for reports and complaints about cheating users

[![w3b3 Recorder to ct.js](w3b3.png "w3b3 Recorder to ct.js")](https://marcobrunodev.itch.io/w3b3recorder)

## How to install

1. Download zip on [marcobrunodev.itch.io/w3b3cursor](https://marcobrunodev.itch.io/w3b3recorder)
2. Import zip on ct.js
   
## Get Started

1. Open ctjs in your PC

# License
[MPL-2.0](https://www.mozilla.org/en-US/MPL/2.0)