# W3B3 Recorder to ct.js - Catmods
> Record gameplays for reports and complaints about cheating users

[![w3b3 Recorder to ct.js](w3b3.png "w3b3 Recorder to ct.js")](https://marcobrunodev.itch.io/w3b3recorder)

## How to install - Todo

1. Download zip on [marcobrunodev.itch.io/w3b3recorder](https://marcobrunodev.itch.io/w3b3recorder)
2. Import zip on ct.js
   
## Get Started - Todo

1. Open ctjs in your PC

## Next features
- [ ] documentation
- [ ] mp4 recording

# License
[MPL-2.0](https://www.mozilla.org/en-US/MPL/2.0)